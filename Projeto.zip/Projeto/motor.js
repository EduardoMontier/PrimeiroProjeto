function carregar() {
	var A = 10; // Estou salvando o valor 10 na variavel A
	var B = "reais"; // Estou salvando o valor "reais" na variavel B
	var C = A + B;	// Estou juntando as variaveis A e B na variavel C
	alert(C); // Estou exibindo o valor da variavel C
}